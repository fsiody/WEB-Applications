# courseEvaluatingSystem
Project for WdAI (Wstęp do Aplikacji Internetowych) WIEiT AGH
