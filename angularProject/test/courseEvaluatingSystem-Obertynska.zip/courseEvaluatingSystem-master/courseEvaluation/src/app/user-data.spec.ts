import { UserData } from './user-data';

describe('UserData', () => {
  it('should create an instance', () => {
    expect(new UserData()).toBeTruthy();
  });
});
