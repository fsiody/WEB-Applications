export interface Mark {
    students:Array<string>;
    marks: Array<number>;
}
