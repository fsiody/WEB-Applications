import { EctsFilterPipe } from './ects-filter.pipe';

describe('EctsFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new EctsFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
