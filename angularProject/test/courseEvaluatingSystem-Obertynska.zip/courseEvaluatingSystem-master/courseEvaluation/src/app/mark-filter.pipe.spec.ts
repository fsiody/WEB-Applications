import { MarkFilterPipe } from './mark-filter.pipe';

describe('MarkFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new MarkFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
