import { SemestrFilterPipe } from './semestr-filter.pipe';

describe('SemestrFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new SemestrFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
