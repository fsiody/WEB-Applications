export interface AddedMark {
    
}
