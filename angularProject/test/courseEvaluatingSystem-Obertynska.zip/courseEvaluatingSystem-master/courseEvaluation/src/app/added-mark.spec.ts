import { AddedMark } from './added-mark';

describe('AddedMark', () => {
  it('should create an instance', () => {
    expect(new AddedMark()).toBeTruthy();
  });
});
